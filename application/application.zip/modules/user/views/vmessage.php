<div id="content">  
    <div class="breadcrumb">
        <a href="<?php echo base_url() ?>">Home</a>
    </div>
    <h1><?php echo GetMessageStatus() == 1 ? 'Confirmation' : 'Error' ?> </h1>
</div>