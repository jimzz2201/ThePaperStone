function messageerror(message)
{
    $('html, body').animate({scrollTop: $('#notification').offset().top}, 'slow');
    $("#notification").empty();
    $("#notification").append("<div class=\"warning\">" + message + "<img src=\"" + baseurl + "asset/user/image/close.png\" alt=\"\" class=\"close\"></div>");
}
function messagesuccess(message)
{
    $('html, body').animate({scrollTop: $('#notification').offset().top}, 'slow');
    $("#notification").empty();
    $("#notification").append("<div class=\"success\">" + message + "<img src=\"" + baseurl + "asset/user/image/close.png\" alt=\"\" class=\"close\"></div>");
}
function RefreshCart()
{
    $.ajax({
        type: 'POST',
        url: baseurl + 'index.php/cart/GetTopCart',
        success: function (data) {
            console.log(data);
            $("#cart").html(data);
        },
        error: function (xhr, status, error) {
            messageerror(xhr.responseText);
        }
    });
    return false;
}
function modaldialog(message)
{
    $("#modaldesc").html(message);
    $('[data-remodal-id = mymodal]').remodal().open();
}
function display(jenis)
{
    if (jenis == "list")
    {
        $(".product-grid").addClass("product-list");
        $(".product-grid").removeClass("product-grid");
    }
    else
    {
        $(".product-list").addClass("product-grid");
        $(".product-list").removeClass("product-list");
    }
}



function isNumberKey(evt) {
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode != 46 && charCode > 31
            && (charCode < 48 || charCode > 57) && charCode != 45)
        return false;

    return true;
}
$(document).ready(function () {

    $(".checkout-heading").click(function () {
        var content = $(this).parent().find('.checkout-content');
        $(".checkout-content").css("display", "none");
        if (content.css("display") == "none")
        {
            content.css("display", "block");
        }
        else
        {
            content.css("display", "none");
        }

    })

})

var LoadBar = {
    show: function () {
        $(".loadbar").removeClass("hide");
    },
    hide: function ()
    {
        $(".loadbar").addClass("hide");
    }

}