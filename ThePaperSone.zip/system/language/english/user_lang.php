<?php


$lang['account_not_activate'] = "Your Account hasn't been verificated";
$lang['account_banned'] = "Your account has been banned by admin";
$lang['account_banned_reason'] = "Your account has been banned by admin because of %s";
$lang['account_login_not_find']="No match for E-Mail Address and/or Password."; 



